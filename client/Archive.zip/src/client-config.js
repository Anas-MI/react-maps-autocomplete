export const GoogleMapsAPI = 'AIzaSyBXxXfKy5wtHEO9XniOvGEKPME-_ldClVk';
